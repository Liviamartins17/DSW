function consisteNome() {
    if (document.trabalheconosco.nome.value.lenght < 10) {
        alert("preencha com o nome completo!");
        document.trabalheconosco.nome.focus();
    }
}

function calculaIdade(dataNasc){
    var dataAtual = new Date();
    var anoAtual = dataAtual.getFullYear();
  
    var dataNascSplit = dataNasc.split('-');
    var diaNasc = dataNascSplit[2];
    var mesNasc = dataNascSplit[1];
    var anoNasc = dataNascSplit[0];
  
    var idade = anoAtual - anoNasc;
    var mesAtual = dataAtual.getMonth() + 1; 
  
    if (mesAtual < mesNasc) {
      idade--; 
    } else {
      if (mesAtual == mesNasc) { 
        if (new Date().getDate() < diaNasc ) { 
          idade--; 
        }
      }
    } 
    document.getElementById('idade').value = idade;
  }

function consisteCPF() {
    if (document.trabalheconosco.cpf.value.lenght > 14) {
        alert("Cpf incorreto!");
        document.trabalheconosco.cpf.focus();
    }
}

function consisteEmail() {
    if (document.getElementById(email).value.lenght < 10) {
        alert("preencha com o email completo");
        document.trabalheconosco.email.focus();
    }
}

function consisteTelefone() {
    if (document.trabalheconosco.telefone.lenght < 11 || document.trabalheconosco.telefone.lenght > 14) {
        alert("preencha o campo com o DDD e telefone completo");
        document.trabalheconosco.telefone.focus();
    }
}

function consisteIdade() {
    if (document.trabalheconosco.idade.value > 130) {
        alert("Preencha com uma idade válida (máx. 130 anos)");
        document.trabalheconosco.idade.style.backgroundColor = "yellow";
        document.trabalheconosco.idade.focus();
    }
    else {
        document.trabalheconosco.idade.style.backgroundColor = "white";
    }
}

function consiste() {
    consisteNome();
    consisteCPF();
    consisteEmail();
    consisteTelefone();
    consisteIdade();
}

