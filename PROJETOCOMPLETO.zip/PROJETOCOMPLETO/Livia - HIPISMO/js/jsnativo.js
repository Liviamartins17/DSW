function consisteNome() {
    if (document.faleconosco.nome.value.lenght < 10) {
        alert("preencha com o nome completo!");
        document.faleconosco.nome.focus();
    }
}

function consisteEmail() {
    if (document.getElementById(email).value.lenght < 10) {
        alert("preencha com o email completo");
        document.faleconosco.email.focus();
    }
}

function consisteTelefone() {
    if (document.faleconosco.telefone.lenght < 11 || document.faleconosco.telefone.lenght > 14) {
        alert("preencha o campo com o DDD e telefone completo");
        document.faleconosco.telefone.focus();
    }
}

function consisteIdade() {
    if (document.faleconosco.idade.value > 130) {
        alert("Preencha com uma idade válida (máx. 130 anos)");
        document.faleconosco.idade.style.backgroundColor = "yellow";
        document.faleconosco.idade.focus();
    }
    else {
        document.faleconosco.idade.style.backgroundColor = "white";
    }
}

function consiste() {
    consisteNome();
    consisteEmail();
    consisteTelefone();
    consisteIdade();
}

function quantificaErrada() {
    document.faleconosco.medidor1.value = document.faleconosco.quantidade.value;
    document.faleconosco.barraProgresso.value = document.faleconosco.quantidade.value * 10;
}

function preencheBarra() {
    document.getElementById("medidor1").value = document.getElementById("quantidade").value;
    document.getElementById("medidor2").value = document.getElementById("quantidade").value / 10;
    document.getElementById("barraProgresso").value = document.getElementById("quantidade").value * 10;
}


function dataHora() {
    var hoje = new Date();

    var dia = hoje.getDate();
    var mes = hoje.getMonth();
    var ano = hoje.getFullYear();
    var hora = hoje.getHours();
    var minuto = hoje.getMinutes();
    var segundo = hoje.getSeconds();

    if (minuto <= 9) {
        minuto = '0' + minuto;
    }
    if (segundo <= 9) {
        segundo = '0' + segundo;
    }

    var meses = new Array(
        'janeiro',
        'fevereiro',
        'março',
        'abril',
        'maio',
        'junho',
        'julho',
        'agosto',
        'setembro',
        'outubro',
        'novembro',
        'dezembro');
    var nomeMes = meses[mes];



    var diaSemana = hoje.getDay();

    switch (diaSemana) {
        case 0: {
            var diaSemanaExtenso = "Domingo, ";
            break;
        }

        case 1: {
            var diaSemanaExtenso = "Segunda-Feira, ";
            break;
        }

        case 3: {
            var diaSemanaExtenso = "Terça-Feira, ";
            break;
        }

        case 4: {
            var diaSemanaExtenso = "Quarta-Feira, ";
            break;
        }

        case 5: {
            var diaSemanaExtenso = "Quinta-Feira, ";
            break;
        }

        case 6: {
            var diaSemanaExtenso = "Sexta-Feira, ";
            break;
        }

        case 7: {
            var diaSemanaExtenso = "Sábado, ";
            break;
        }
    }

    if (hora < 12) {
        var saudacao = 'Bom Dia';
    } else if (datahora >= 18) {
        var saudacao = 'Boa Noite';
    } else {
        var saudacao = 'Boa Tarde';
    }

    document.faleconosco.hoje.value = diaSemanaExtenso + dia + ' de ' + nomeMes + ' de ' + ano + ' ' + hora + ':' + minuto + ':' + segundo + ' ' + saudacao;
    idenetificaBrowser()
}

function atualizaHora() {
    window.setInterval("dataHora()", 1000);
}

function idenetificaBrowser() {
    document.faleconosco.navegador.value = "Você está no navegador: " + navigator.appName;

}